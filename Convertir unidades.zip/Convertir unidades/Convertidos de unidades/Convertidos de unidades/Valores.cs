﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Convertidos_de_unidades
{
    class Valores
    {
        public double Dato1 { get; set; }

        public double Dato2 { get; set; }

        public double Dato3 { get; set; }
    }
}
